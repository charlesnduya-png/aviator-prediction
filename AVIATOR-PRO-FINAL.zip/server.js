const http = require("http");
const fs = require("fs");
const path = require("path");
const { exec } = require("child_process");

const PORT = 8080;
const ROOT = __dirname;

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".webmanifest": "application/manifest+json",
};

function getLanIp() {
  const nets = require("os").networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === "IPv4" && !net.internal) return net.address;
    }
  }
  return "127.0.0.1";
}

function writeUrlFile() {
  const ip = getLanIp();
  const url = `http://${ip}:${PORT}`;
  fs.writeFileSync(
    path.join(ROOT, "lan-url.json"),
    JSON.stringify({ url, ip, port: PORT }, null, 2)
  );
  return url;
}

const server = http.createServer((req, res) => {
  let filePath = path.join(ROOT, decodeURIComponent(req.url.split("?")[0]));
  if (filePath.endsWith(path.sep)) filePath += "index.html";
  if (path.dirname(filePath).indexOf(ROOT) !== 0) {
    res.writeHead(403);
    return res.end("Forbidden");
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      return res.end("Not found");
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
    res.end(data);
  });
});

const phoneUrl = writeUrlFile();
server.listen(PORT, "0.0.0.0", () => {
  console.log();
  console.log("  Aviator Pro Predictor - Phone Server");
  console.log("  =====================================");
  console.log();
  console.log(`  Phone link:  ${phoneUrl}`);
  console.log(`  QR page:     http://localhost:${PORT}/scan.html`);
  console.log();
  console.log("  Scan the QR with your phone (same Wi-Fi).");
  console.log("  Press Ctrl+C to stop");
  console.log();
  exec(`start http://localhost:${PORT}/scan.html`);
});
